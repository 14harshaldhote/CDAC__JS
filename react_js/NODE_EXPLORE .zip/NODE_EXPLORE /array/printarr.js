const { arr } = require('./arrayobj');
const { printArray } = require('./gotfun');


console.log("Person Array:");
printArray(arr);