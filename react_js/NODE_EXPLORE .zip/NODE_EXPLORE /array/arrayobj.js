var arr=[
    {name:'shir',age:23},
    {name:'Vai',age:26},
    {name:'Nump',age:32},
]
console.log(module)
module.exports={
    arr
}
console.log(module)