const add=(n1,n2)=>{
    console.log(n1+n2)
}
const sub=(n1,n2)=>{
    console.log(n1-n2)
}
const mul=(n1,n2)=>{
    console.log(n1*n2)
}
const div=(n1,n2)=>{
    console.log(n1/n2)
}
module.exports={
    add,
    sub,
    mul,
    div
}