let n1=10
let n2=20

let add=n1+n2
console.log(add)