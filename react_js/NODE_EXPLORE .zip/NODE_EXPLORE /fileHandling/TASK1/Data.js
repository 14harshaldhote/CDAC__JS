const data = "Welcome to Working culture";

module.exports = {
    data
};